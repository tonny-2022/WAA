package com.lab3.lab3.entity;

public class Author {
	

}
