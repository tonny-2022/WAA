export default function FooterComponent(){

    return (
      
      <footer className="footer"> 
        <div className="container">
             <hr/>footer
        </div> 
      </footer>
      )
   }