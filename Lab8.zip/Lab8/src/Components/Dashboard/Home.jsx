export default function Home (){


    return(
        <div className="container">
          <h1> Welcome to Home page</h1>

        </div>
    )
}